function togglePassword(id,btn){
 const el=document.getElementById(id);
 if(el.type==='password'){el.type='text';btn.textContent='🙈';}
 else{el.type='password';btn.textContent='👁';}
}
function showDesign(name){
 document.getElementById('goldPage').classList.toggle('active',name==='gold');
 document.getElementById('whitePage').classList.toggle('active',name==='white');
 localStorage.setItem('loginDesign',name);
}
document.addEventListener('DOMContentLoaded',()=>{
 const d=localStorage.getItem('loginDesign');
 if(d) showDesign(d);
});
